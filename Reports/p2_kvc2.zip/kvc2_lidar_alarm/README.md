# kvc2_lidar_alarm

Package with replacement for lidar_alarm which, instead of just checking a point directly in front of the robot, checks for a "corridor." Intended for use with reactive_commander, but published data can be used by any node. 

This code subscribes to topic `robot0/laser_0`, which is published by the Simple 2-D Robot simulator.
If the ping distance is less than some danger threshold for a given ray, the lidar listener publishers a warning signal on
topic `lidar_alarm`.  The distance of the forward ping is also published, on topic `lidar_dist`.

## Example usage
roslaunch stdr_launchers server_with_map_and_gui_plus_robot.launch
rosrun kvc2_lidar_alarm kvc2_lidar_alarm
rosrun stdr_control reactive_commander
